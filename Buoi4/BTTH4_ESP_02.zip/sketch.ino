#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";
const char* MQTT_HOST = "broker.hivemq.com";
const uint16_t MQTT_PORT = 1883;
const char* MQTT_TOPIC = "demo/esp32/temperature/test-73142";

constexpr int LED_PIN = 18;
constexpr float HOT_THRESHOLD_C = 35.0f;

WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
LiquidCrystal_I2C lcd(0x27, 16, 2);

unsigned long lastReconnectAttempt = 0;

void showWaiting(const char* line2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("MQTT Subscriber");
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  char buffer[32];
  if (length == 0 || length >= sizeof(buffer)) {
    Serial.println("Invalid MQTT payload length");
    return;
  }
  memcpy(buffer, payload, length);
  buffer[length] = '\0';

  char* endPtr;
  float temperature = strtof(buffer, &endPtr);
  if (endPtr == buffer || *endPtr != '\0' || !isfinite(temperature)) {
    Serial.print("Invalid temperature: ");
    Serial.println(buffer);
    return;
  }

  bool hot = temperature > HOT_THRESHOLD_C;
  digitalWrite(LED_PIN, hot ? HIGH : LOW);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature, 1);
  lcd.write((uint8_t)223);
  lcd.print("C");
  lcd.setCursor(0, 1);
  lcd.print(hot ? "HOT! LED: ON" : "NORMAL LED: OFF");

  Serial.print("Received [");
  Serial.print(topic);
  Serial.print("]: ");
  Serial.print(temperature, 2);
  Serial.println(hot ? " C -> LED ON" : " C -> LED OFF");
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, 6);
  showWaiting("Connecting WiFi");
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(250);
    Serial.print('.');
  }
  Serial.println(" connected");
  showWaiting("Waiting MQTT...");
}

void reconnectMQTT() {
  if (mqtt.connected() || millis() - lastReconnectAttempt < 3000) return;
  lastReconnectAttempt = millis();

  String clientId = "wokwi-sub-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  Serial.print("Connecting MQTT... ");
  if (mqtt.connect(clientId.c_str())) {
    if (mqtt.subscribe(MQTT_TOPIC)) {
      Serial.print("Subscribed to: ");
      Serial.println(MQTT_TOPIC);
      showWaiting("Waiting temp...");
    } else {
      Serial.println("MQTT subscribe failed");
    }
  } else {
    Serial.print("failed, state=");
    Serial.println(mqtt.state());
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  showWaiting("Starting...");

  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMessage);
  mqtt.setKeepAlive(30);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    digitalWrite(LED_PIN, LOW);
    connectWiFi();
  }
  if (!mqtt.connected()) reconnectMQTT();
  mqtt.loop();
  delay(10);
}