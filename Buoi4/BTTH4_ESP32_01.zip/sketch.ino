#include <WiFi.h>
#include <PubSubClient.h>
#include <DHTesp.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";
const char* MQTT_HOST = "broker.hivemq.com";
const uint16_t MQTT_PORT = 1883;
const char* MQTT_TOPIC = "demo/esp32/temperature/test-73142";

constexpr int DHT_PIN = 15;
constexpr unsigned long PUBLISH_INTERVAL_MS = 2000;
DHTesp dht;
WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
unsigned long lastPublish = 0;
unsigned long lastMqttAttempt = 0;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("Connecting WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, 6);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" connected");
}

void ensureMqtt() {
  if (mqtt.connected() || millis() - lastMqttAttempt < 3000) return;
  lastMqttAttempt = millis();
  String clientId = "wokwi-pub-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  Serial.print("Connecting MQTT... ");
  if (mqtt.connect(clientId.c_str())) Serial.println("connected");
  else { Serial.print("failed, state="); Serial.println(mqtt.state()); }
}

void setup() {
  Serial.begin(115200);
  dht.setup(DHT_PIN, DHTesp::DHT22);
  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  lastMqttAttempt = millis() - 3000;
  lastPublish = millis() - PUBLISH_INTERVAL_MS;
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); }
  ensureMqtt();
  mqtt.loop();
  if (millis() - lastPublish >= PUBLISH_INTERVAL_MS) {
    lastPublish = millis();
    TempAndHumidity data = dht.getTempAndHumidity();
    if (isnan(data.temperature)) { Serial.println("DHT22 read failed"); return; }
    if (!mqtt.connected()) { Serial.println("MQTT disconnected, skipped publish"); return; }
    char payload[20];
    snprintf(payload, sizeof(payload), "%.2f", data.temperature);
    if (mqtt.publish(MQTT_TOPIC, payload)) {
      Serial.printf("Published: %s C | topic: %s\n", payload, MQTT_TOPIC);
    } else Serial.println("Publish failed");
  }
}