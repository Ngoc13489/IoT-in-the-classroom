// Wokwi Custom Chip - For docs and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT
// Copyright 2023 NGOC NGUYEN

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t pin_out;
  uint32_t temp_attr;
} chip_state_t;

static void update_chip(void *user_data) {
  chip_state_t *chip = (chip_state_t *)user_data;
  
  // Read current temperature value from slider (float)
  float temp = attr_read_float(chip->temp_attr);

  // LM35 formula: 10 mV / degree C (0.010 V / degree C)
  float voltage = temp * 0.010f;
  pin_dac_write(chip->pin_out, voltage);
}

void chip_init(void) {
  chip_state_t *chip = (chip_state_t *)malloc(sizeof(chip_state_t));
  chip->pin_out = pin_init("OUT", ANALOG);
  
  // Initialize floating-point attribute with ID "temp" and default value 25.0
  chip->temp_attr = attr_init_float("temp", 25.0f);

  // Setup periodic timer to poll slider every 50ms (50000 microseconds)
  const timer_config_t timer_config = {
    .callback = update_chip,
    .user_data = chip,
  };
  timer_t timer_id = timer_init(&timer_config);
  timer_start(timer_id, 50000, true);

  // Initial update
  update_chip(chip);
}